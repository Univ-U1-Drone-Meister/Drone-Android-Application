package kr.seon.u1.drone_fly_down_flow;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import kr.seon.u1.R;

public class RadarSetting extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_radar_setting);

    }

}
